import React from 'react';
import "../App.css";

function Home() {
  return (
    <div className="home-welcome">
      <h2>🎉 बधाई हो! 🎉</h2>
      <p>आप हमारी E-Commerce वेबसाइट पर Login और Register कर चुके हैं।</p>
      <p>अब आप हमारे Products देख सकते हैं और Shopping शुरू कर सकते हैं। 🛒</p>
    </div>
  );
}

export default Home;
